package syncregions;

public class BoilerActuator0 {
	
	public execute(int temperatureDifference0, boolean boilerStatus0) { 
		
		//sync _bfpnGUbFEeqXnfGWlV2_80, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
