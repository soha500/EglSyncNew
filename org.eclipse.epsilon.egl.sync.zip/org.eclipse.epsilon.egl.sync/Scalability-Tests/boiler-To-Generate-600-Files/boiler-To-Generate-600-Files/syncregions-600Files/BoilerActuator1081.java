package syncregions;

public class BoilerActuator1081 {
	
	public execute(int temperatureDifference1081, boolean boilerStatus1081) { 
		
		//sync _bfpnGUbFEeqXnfGWlV1081, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
