package syncregions;

public class BoilerActuator1131 {
	
	public execute(int temperatureDifference1131, boolean boilerStatus1131) { 
		
		//sync _bfpnGUbFEeqXnfGWlV1131, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
