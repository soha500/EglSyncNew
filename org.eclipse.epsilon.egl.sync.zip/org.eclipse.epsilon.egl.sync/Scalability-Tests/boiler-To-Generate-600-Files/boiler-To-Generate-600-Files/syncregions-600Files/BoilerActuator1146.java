package syncregions;

public class BoilerActuator1146 {
	
	public execute(int temperatureDifference1146, boolean boilerStatus1146) { 
		
		//sync _bfpnGUbFEeqXnfGWlV1146, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
