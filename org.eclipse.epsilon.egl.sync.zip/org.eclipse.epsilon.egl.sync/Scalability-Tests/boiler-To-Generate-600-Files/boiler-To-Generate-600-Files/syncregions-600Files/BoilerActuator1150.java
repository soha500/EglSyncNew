package syncregions;

public class BoilerActuator1150 {
	
	public execute(int temperatureDifference1150, boolean boilerStatus1150) { 
		
		//sync _bfpnGUbFEeqXnfGWlV1150, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
