package syncregions;

public class BoilerActuator1166 {
	
	public execute(int temperatureDifference1166, boolean boilerStatus1166) { 
		
		//sync _bfpnGUbFEeqXnfGWlV1166, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
