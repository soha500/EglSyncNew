package syncregions;

public class BoilerActuator1202 {
	
	public execute(int temperatureDifference1202, boolean boilerStatus1202) { 
		
		//sync _bfpnGUbFEeqXnfGWlV1202, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
