package syncregions;

public class BoilerActuator1279 {
	
	public execute(int temperatureDifference1279, boolean boilerStatus1279) { 
		
		//sync _bfpnGUbFEeqXnfGWlV1279, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
