package syncregions;

public class BoilerActuator1280 {
	
	public execute(int temperatureDifference1280, boolean boilerStatus1280) { 
		
		//sync _bfpnGUbFEeqXnfGWlV1280, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
