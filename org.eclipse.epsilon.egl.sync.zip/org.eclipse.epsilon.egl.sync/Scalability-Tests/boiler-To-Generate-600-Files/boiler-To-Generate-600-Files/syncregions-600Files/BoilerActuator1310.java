package syncregions;

public class BoilerActuator1310 {
	
	public execute(int temperatureDifference1310, boolean boilerStatus1310) { 
		
		//sync _bfpnGUbFEeqXnfGWlV1310, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
