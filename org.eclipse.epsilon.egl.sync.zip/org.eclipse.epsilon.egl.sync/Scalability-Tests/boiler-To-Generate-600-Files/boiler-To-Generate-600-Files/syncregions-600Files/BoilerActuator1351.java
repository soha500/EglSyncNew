package syncregions;

public class BoilerActuator1351 {
	
	public execute(int temperatureDifference1351, boolean boilerStatus1351) { 
		
		//sync _bfpnGUbFEeqXnfGWlV1351, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
