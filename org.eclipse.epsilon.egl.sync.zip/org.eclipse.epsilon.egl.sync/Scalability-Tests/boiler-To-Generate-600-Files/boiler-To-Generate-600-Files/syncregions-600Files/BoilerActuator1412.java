package syncregions;

public class BoilerActuator1412 {
	
	public execute(int temperatureDifference1412, boolean boilerStatus1412) { 
		
		//sync _bfpnGUbFEeqXnfGWlV1412, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
