package syncregions;

public class BoilerActuator1473 {
	
	public execute(int temperatureDifference1473, boolean boilerStatus1473) { 
		
		//sync _bfpnGUbFEeqXnfGWlV1473, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
