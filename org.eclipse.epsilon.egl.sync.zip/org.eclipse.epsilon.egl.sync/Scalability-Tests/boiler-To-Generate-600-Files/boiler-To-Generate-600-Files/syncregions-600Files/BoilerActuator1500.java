package syncregions;

public class BoilerActuator1500 {
	
	public execute(int temperatureDifference1500, boolean boilerStatus1500) { 
		
		//sync _bfpnGUbFEeqXnfGWlV1500, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
