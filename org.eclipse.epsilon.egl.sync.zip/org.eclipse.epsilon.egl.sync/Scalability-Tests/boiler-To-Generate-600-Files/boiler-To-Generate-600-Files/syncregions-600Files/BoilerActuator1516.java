package syncregions;

public class BoilerActuator1516 {
	
	public execute(int temperatureDifference1516, boolean boilerStatus1516) { 
		
		//sync _bfpnGUbFEeqXnfGWlV1516, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
