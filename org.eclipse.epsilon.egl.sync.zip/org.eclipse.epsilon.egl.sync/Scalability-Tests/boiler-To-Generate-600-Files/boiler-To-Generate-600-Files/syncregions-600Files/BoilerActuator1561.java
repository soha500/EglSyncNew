package syncregions;

public class BoilerActuator1561 {
	
	public execute(int temperatureDifference1561, boolean boilerStatus1561) { 
		
		//sync _bfpnGUbFEeqXnfGWlV1561, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
