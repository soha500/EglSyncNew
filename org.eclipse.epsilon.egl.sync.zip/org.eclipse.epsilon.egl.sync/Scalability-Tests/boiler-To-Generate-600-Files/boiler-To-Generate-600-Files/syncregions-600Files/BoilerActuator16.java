package syncregions;

public class BoilerActuator16 {
	
	public execute(int temperatureDifference16, boolean boilerStatus16) { 
		
		//sync _bfpnGUbFEeqXnfGWlV2_16, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
