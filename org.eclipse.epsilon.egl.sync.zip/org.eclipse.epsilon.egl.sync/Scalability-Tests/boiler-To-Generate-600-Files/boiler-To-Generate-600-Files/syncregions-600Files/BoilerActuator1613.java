package syncregions;

public class BoilerActuator1613 {
	
	public execute(int temperatureDifference1613, boolean boilerStatus1613) { 
		
		//sync _bfpnGUbFEeqXnfGWlV1613, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
