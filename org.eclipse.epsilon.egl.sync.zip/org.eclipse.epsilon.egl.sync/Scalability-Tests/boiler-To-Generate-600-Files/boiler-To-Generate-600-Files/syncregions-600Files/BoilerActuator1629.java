package syncregions;

public class BoilerActuator1629 {
	
	public execute(int temperatureDifference1629, boolean boilerStatus1629) { 
		
		//sync _bfpnGUbFEeqXnfGWlV1629, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
