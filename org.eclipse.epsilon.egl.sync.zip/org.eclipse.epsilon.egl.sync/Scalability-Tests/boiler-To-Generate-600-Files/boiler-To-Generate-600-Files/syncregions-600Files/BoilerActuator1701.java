package syncregions;

public class BoilerActuator1701 {
	
	public execute(int temperatureDifference1701, boolean boilerStatus1701) { 
		
		//sync _bfpnGUbFEeqXnfGWlV1701, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
