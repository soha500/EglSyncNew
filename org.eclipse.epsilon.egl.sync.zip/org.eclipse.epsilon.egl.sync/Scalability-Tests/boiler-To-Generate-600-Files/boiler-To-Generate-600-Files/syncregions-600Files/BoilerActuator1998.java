package syncregions;

public class BoilerActuator1998 {
	
	public execute(int temperatureDifference1998, boolean boilerStatus1998) { 
		
		//sync _bfpnGUbFEeqXnfGWlV1998, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
