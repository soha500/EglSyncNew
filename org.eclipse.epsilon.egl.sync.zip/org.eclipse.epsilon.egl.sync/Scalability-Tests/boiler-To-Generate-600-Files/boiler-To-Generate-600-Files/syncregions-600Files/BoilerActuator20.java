package syncregions;

public class BoilerActuator20 {
	
	public execute(int temperatureDifference20, boolean boilerStatus20) { 
		
		//sync _bfpnGUbFEeqXnfGWlV2_20, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
