package syncregions;

public class BoilerActuator2013 {
	
	public execute(int temperatureDifference2013, boolean boilerStatus2013) { 
		
		//sync _bfpnGUbFEeqXnfGWlV2013, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
