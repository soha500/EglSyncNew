package syncregions;

public class BoilerActuator2091 {
	
	public execute(int temperatureDifference2091, boolean boilerStatus2091) { 
		
		//sync _bfpnGUbFEeqXnfGWlV2091, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
