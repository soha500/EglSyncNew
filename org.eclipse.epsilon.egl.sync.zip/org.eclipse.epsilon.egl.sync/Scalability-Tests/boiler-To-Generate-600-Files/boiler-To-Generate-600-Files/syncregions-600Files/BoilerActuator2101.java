package syncregions;

public class BoilerActuator2101 {
	
	public execute(int temperatureDifference2101, boolean boilerStatus2101) { 
		
		//sync _bfpnGUbFEeqXnfGWlV2101, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
