package syncregions;

public class BoilerActuator2121 {
	
	public execute(int temperatureDifference2121, boolean boilerStatus2121) { 
		
		//sync _bfpnGUbFEeqXnfGWlV2121, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
