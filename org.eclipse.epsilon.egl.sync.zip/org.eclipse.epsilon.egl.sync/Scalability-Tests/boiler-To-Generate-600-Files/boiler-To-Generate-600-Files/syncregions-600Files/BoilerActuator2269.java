package syncregions;

public class BoilerActuator2269 {
	
	public execute(int temperatureDifference2269, boolean boilerStatus2269) { 
		
		//sync _bfpnGUbFEeqXnfGWlV2269, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
