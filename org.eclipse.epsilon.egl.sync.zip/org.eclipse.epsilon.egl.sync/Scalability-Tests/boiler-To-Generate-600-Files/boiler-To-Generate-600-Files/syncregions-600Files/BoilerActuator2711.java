package syncregions;

public class BoilerActuator2711 {
	
	public execute(int temperatureDifference2711, boolean boilerStatus2711) { 
		
		//sync _bfpnGUbFEeqXnfGWlV2711, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
