package syncregions;

public class BoilerActuator335 {
	
	public execute(int temperatureDifference335, boolean boilerStatus335) { 
		
		//sync _bfpnGUbFEeqXnfGWlV2335, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
