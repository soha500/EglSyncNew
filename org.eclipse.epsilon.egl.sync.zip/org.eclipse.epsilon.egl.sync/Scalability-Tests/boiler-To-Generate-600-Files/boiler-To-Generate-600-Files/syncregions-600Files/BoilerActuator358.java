package syncregions;

public class BoilerActuator358 {
	
	public execute(int temperatureDifference358, boolean boilerStatus358) { 
		
		//sync _bfpnGUbFEeqXnfGWlV2358, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
