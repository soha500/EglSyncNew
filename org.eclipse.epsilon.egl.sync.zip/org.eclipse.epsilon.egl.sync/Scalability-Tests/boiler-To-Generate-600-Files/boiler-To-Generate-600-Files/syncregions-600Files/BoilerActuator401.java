package syncregions;

public class BoilerActuator401 {
	
	public execute(int temperatureDifference401, boolean boilerStatus401) { 
		
		//sync _bfpnGUbFEeqXnfGWlV2401, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
