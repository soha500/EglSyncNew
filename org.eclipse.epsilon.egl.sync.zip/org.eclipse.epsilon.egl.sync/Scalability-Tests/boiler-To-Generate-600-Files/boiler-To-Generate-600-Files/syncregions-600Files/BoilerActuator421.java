package syncregions;

public class BoilerActuator421 {
	
	public execute(int temperatureDifference421, boolean boilerStatus421) { 
		
		//sync _bfpnGUbFEeqXnfGWlV2421, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
