package syncregions;

public class BoilerActuator460 {
	
	public execute(int temperatureDifference460, boolean boilerStatus460) { 
		
		//sync _bfpnGUbFEeqXnfGWlV2460, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
