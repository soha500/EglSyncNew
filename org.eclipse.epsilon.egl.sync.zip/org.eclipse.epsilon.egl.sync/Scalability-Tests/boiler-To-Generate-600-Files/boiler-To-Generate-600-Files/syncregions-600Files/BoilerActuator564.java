package syncregions;

public class BoilerActuator564 {
	
	public execute(int temperatureDifference564, boolean boilerStatus564) { 
		
		//sync _bfpnGUbFEeqXnfGWlV2564, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
