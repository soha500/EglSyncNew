package syncregions;

public class BoilerActuator572 {
	
	public execute(int temperatureDifference572, boolean boilerStatus572) { 
		
		//sync _bfpnGUbFEeqXnfGWlV2572, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
