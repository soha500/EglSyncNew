package syncregions;

public class BoilerActuator708 {
	
	public execute(int temperatureDifference708, boolean boilerStatus708) { 
		
		//sync _bfpnGUbFEeqXnfGWlV2708, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
