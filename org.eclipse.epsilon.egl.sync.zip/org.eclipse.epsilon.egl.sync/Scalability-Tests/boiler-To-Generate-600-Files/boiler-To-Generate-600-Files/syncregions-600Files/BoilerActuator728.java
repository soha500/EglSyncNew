package syncregions;

public class BoilerActuator728 {
	
	public execute(int temperatureDifference728, boolean boilerStatus728) { 
		
		//sync _bfpnGUbFEeqXnfGWlV2728, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
