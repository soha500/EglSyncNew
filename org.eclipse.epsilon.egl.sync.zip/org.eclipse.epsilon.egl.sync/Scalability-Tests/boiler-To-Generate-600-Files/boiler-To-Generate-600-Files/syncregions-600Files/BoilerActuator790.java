package syncregions;

public class BoilerActuator790 {
	
	public execute(int temperatureDifference790, boolean boilerStatus790) { 
		
		//sync _bfpnGUbFEeqXnfGWlV2790, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
