package syncregions;

public class BoilerActuator860 {
	
	public execute(int temperatureDifference860, boolean boilerStatus860) { 
		
		//sync _bfpnGUbFEeqXnfGWlV2860, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
