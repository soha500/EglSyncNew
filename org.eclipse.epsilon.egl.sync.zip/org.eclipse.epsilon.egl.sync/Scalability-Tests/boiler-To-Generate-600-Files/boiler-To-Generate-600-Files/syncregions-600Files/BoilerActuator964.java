package syncregions;

public class BoilerActuator964 {
	
	public execute(int temperatureDifference964, boolean boilerStatus964) { 
		
		//sync _bfpnGUbFEeqXnfGWlV2964, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
