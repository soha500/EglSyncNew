package syncregions;

public class BoilerActuator972 {
	
	public execute(int temperatureDifference972, boolean boilerStatus972) { 
		
		//sync _bfpnGUbFEeqXnfGWlV2972, behaviour     			 
Half Change - return temperature - targetTemperature;
		//endSync

	}

}
