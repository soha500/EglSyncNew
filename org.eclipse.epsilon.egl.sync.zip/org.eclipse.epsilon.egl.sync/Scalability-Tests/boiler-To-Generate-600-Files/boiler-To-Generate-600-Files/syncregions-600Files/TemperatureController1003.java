package syncregions;

public class TemperatureController1003 {
	
	public execute(int temperature1003, int targetTemperature1003) { 
		
		//sync _bfpnFUbFEeqXnfGWlV1003, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
