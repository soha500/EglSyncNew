package syncregions;

public class TemperatureController1107 {
	
	public execute(int temperature1107, int targetTemperature1107) { 
		
		//sync _bfpnFUbFEeqXnfGWlV1107, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
