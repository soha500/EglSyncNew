package syncregions;

public class TemperatureController1131 {
	
	public execute(int temperature1131, int targetTemperature1131) { 
		
		//sync _bfpnFUbFEeqXnfGWlV1131, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
