package syncregions;

public class TemperatureController1146 {
	
	public execute(int temperature1146, int targetTemperature1146) { 
		
		//sync _bfpnFUbFEeqXnfGWlV1146, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
