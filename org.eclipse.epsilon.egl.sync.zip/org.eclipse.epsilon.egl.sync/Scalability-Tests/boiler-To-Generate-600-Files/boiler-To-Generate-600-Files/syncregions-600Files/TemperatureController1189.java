package syncregions;

public class TemperatureController1189 {
	
	public execute(int temperature1189, int targetTemperature1189) { 
		
		//sync _bfpnFUbFEeqXnfGWlV1189, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
