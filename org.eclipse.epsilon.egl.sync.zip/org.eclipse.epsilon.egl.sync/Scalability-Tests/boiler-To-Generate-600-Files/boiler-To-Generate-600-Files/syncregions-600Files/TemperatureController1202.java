package syncregions;

public class TemperatureController1202 {
	
	public execute(int temperature1202, int targetTemperature1202) { 
		
		//sync _bfpnFUbFEeqXnfGWlV1202, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
