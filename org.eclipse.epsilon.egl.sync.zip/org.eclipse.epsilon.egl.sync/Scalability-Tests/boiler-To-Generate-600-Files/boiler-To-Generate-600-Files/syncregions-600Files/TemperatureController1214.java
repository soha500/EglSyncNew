package syncregions;

public class TemperatureController1214 {
	
	public execute(int temperature1214, int targetTemperature1214) { 
		
		//sync _bfpnFUbFEeqXnfGWlV1214, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
