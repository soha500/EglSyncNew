package syncregions;

public class TemperatureController1310 {
	
	public execute(int temperature1310, int targetTemperature1310) { 
		
		//sync _bfpnFUbFEeqXnfGWlV1310, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
