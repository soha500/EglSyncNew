package syncregions;

public class TemperatureController1392 {
	
	public execute(int temperature1392, int targetTemperature1392) { 
		
		//sync _bfpnFUbFEeqXnfGWlV1392, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
