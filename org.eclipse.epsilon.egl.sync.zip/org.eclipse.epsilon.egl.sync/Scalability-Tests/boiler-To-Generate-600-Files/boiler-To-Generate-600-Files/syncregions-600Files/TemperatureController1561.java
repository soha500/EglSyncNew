package syncregions;

public class TemperatureController1561 {
	
	public execute(int temperature1561, int targetTemperature1561) { 
		
		//sync _bfpnFUbFEeqXnfGWlV1561, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
