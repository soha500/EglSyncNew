package syncregions;

public class TemperatureController1594 {
	
	public execute(int temperature1594, int targetTemperature1594) { 
		
		//sync _bfpnFUbFEeqXnfGWlV1594, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
