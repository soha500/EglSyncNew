package syncregions;

public class TemperatureController1613 {
	
	public execute(int temperature1613, int targetTemperature1613) { 
		
		//sync _bfpnFUbFEeqXnfGWlV1613, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
