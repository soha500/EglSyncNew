package syncregions;

public class TemperatureController1701 {
	
	public execute(int temperature1701, int targetTemperature1701) { 
		
		//sync _bfpnFUbFEeqXnfGWlV1701, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
