package syncregions;

public class TemperatureController2013 {
	
	public execute(int temperature2013, int targetTemperature2013) { 
		
		//sync _bfpnFUbFEeqXnfGWlV2013, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
