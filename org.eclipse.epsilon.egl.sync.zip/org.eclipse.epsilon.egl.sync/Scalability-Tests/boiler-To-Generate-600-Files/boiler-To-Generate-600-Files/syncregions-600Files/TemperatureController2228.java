package syncregions;

public class TemperatureController2228 {
	
	public execute(int temperature2228, int targetTemperature2228) { 
		
		//sync _bfpnFUbFEeqXnfGWlV2228, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
