package syncregions;

public class TemperatureController261 {
	
	public execute(int temperature261, int targetTemperature261) { 
		
		//sync _bfpnFUbFEeqXnfGWlV2261, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
