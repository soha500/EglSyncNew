package syncregions;

public class TemperatureController2711 {
	
	public execute(int temperature2711, int targetTemperature2711) { 
		
		//sync _bfpnFUbFEeqXnfGWlV2711, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
