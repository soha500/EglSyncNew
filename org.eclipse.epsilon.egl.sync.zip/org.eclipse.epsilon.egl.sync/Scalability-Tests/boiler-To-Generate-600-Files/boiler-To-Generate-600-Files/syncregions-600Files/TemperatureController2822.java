package syncregions;

public class TemperatureController2822 {
	
	public execute(int temperature2822, int targetTemperature2822) { 
		
		//sync _bfpnFUbFEeqXnfGWlV2822, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
