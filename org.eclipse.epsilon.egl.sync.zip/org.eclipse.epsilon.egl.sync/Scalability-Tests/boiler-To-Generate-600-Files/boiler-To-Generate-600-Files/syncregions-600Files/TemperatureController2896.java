package syncregions;

public class TemperatureController2896 {
	
	public execute(int temperature2896, int targetTemperature2896) { 
		
		//sync _bfpnFUbFEeqXnfGWlV2896, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
