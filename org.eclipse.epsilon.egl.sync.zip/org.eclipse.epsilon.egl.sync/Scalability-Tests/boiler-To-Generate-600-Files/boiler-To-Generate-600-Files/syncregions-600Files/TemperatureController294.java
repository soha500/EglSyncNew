package syncregions;

public class TemperatureController294 {
	
	public execute(int temperature294, int targetTemperature294) { 
		
		//sync _bfpnFUbFEeqXnfGWlV2294, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
