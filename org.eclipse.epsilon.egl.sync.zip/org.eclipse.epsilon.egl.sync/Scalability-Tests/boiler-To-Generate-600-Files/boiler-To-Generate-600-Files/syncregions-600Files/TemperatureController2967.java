package syncregions;

public class TemperatureController2967 {
	
	public execute(int temperature2967, int targetTemperature2967) { 
		
		//sync _bfpnFUbFEeqXnfGWlV2967, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
