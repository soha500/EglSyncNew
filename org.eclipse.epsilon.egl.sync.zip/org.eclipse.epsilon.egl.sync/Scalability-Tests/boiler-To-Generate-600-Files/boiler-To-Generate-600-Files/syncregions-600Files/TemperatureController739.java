package syncregions;

public class TemperatureController739 {
	
	public execute(int temperature739, int targetTemperature739) { 
		
		//sync _bfpnFUbFEeqXnfGWlV2739, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
