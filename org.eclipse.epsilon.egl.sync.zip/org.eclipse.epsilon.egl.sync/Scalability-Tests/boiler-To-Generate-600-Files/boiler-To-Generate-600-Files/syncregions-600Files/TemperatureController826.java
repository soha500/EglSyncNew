package syncregions;

public class TemperatureController826 {
	
	public execute(int temperature826, int targetTemperature826) { 
		
		//sync _bfpnFUbFEeqXnfGWlV2826, behaviour     			 
1-if(temperatureDifference > 0 && boilerStatus == true) { return 1; } else if (temperatureDifference < 0 && boilerStatus == false) { return 2; } else return 0;
		//endSync

	}

}
