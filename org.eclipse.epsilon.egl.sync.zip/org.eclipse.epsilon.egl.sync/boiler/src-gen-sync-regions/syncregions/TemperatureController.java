package syncregions;

public class TemperatureController {
	
	public int execute(int temperature, int targetTemperature) {

		//sync _bfpnFUbFEeqXnfGWlV2_8A, code     			 

		return temperature - targetTemperature;

		//endSync
	}
	
}